package com.randomclient.dataload;

import java.io.InputStream;
import java.util.Date;

public interface InvoiceDataAccess {

	int getMeterFor(String supplier, String fuelType);

	/**
	 * Returns the invoice id or null if none exists
	 */
	Integer getInvoice(int meter, Date date);

	/**
	 * Returns the most recent invoice prior to the given date
	 */
	Integer getMostRecentPriorInvoice(int meter, Date date);
	
	/**
	 * Returns the start of the meter's existence
	 */
	Date getMeterStartDate(int meter);
	
	/**
	 * Returns the XML for an invoice as it stands, readable from the returned InputStream
	 */
	InputStream getInvoiceXML(int invoice);
}
